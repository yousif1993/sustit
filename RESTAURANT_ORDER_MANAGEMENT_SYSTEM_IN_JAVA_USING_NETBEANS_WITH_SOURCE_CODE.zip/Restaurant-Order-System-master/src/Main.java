class Main {
    
    public Main()//constructor
    {
        
    }
    
     //variable declaration
    private String Main, MainPrice;
    
    //getters and setters
    public String getMain()
      {
         return Main;
      }
     
    public String getMainPrice()
      {
         return MainPrice;
      }
        protected void setMain(String iMain)
      {
         this.Main = iMain;
      }
     
     protected void setMainPrice(String iMainPrice)
      {
         this.MainPrice = iMainPrice;
      }
}
